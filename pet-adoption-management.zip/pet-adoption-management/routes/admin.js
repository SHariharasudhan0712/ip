const express = require('express');
const db = require('../config/db');
const { requireLogin, requireAdmin } = require('../middleware/auth');
const router = express.Router();

router.use(requireLogin, requireAdmin);

router.get('/dashboard', async (req, res) => {
  const [[a]] = await db.query('SELECT COUNT(*) AS c FROM pets');
  const [[b]] = await db.query("SELECT COUNT(*) AS c FROM pets WHERE status = 'Available'");
  const [[c]] = await db.query("SELECT COUNT(*) AS c FROM users WHERE role = 'user'");
  const [[d]] = await db.query('SELECT COUNT(*) AS c FROM adoption_requests');
  res.render('admin/dashboard', { title: 'Admin Dashboard', stats: { pets: a.c, available: b.c, users: c.c, requests: d.c } });
});

router.get('/pets', async (req, res) => {
  const [pets] = await db.query('SELECT * FROM pets ORDER BY id');
  res.render('admin/pets', { title: 'Manage Pets', pets });
});

router.get('/pets/add', (req, res) => res.render('admin/add-pet', { title: 'Add Pet' }));

function petFields(b) {
  return [b.pet_name, b.pet_type, b.breed, b.age, b.gender, b.description, b.vaccinated, b.status];
}

router.post('/pets/add', async (req, res) => {
  const b = req.body;
  if (!b.pet_name || !b.pet_type || !b.breed || !b.age) {
    req.session.flash = { type: 'error', msg: 'Name, type, breed and age are required.' };
    return res.redirect('/admin/pets/add');
  }
  await db.query('INSERT INTO pets (pet_name, pet_type, breed, age, gender, description, vaccinated, status) VALUES (?,?,?,?,?,?,?,?)', petFields(b));
  req.session.flash = { type: 'success', msg: 'Pet added successfully.' };
  res.redirect('/admin/pets');
});

router.get('/pets/edit/:id', async (req, res) => {
  const [rows] = await db.query('SELECT * FROM pets WHERE id = ?', [req.params.id]);
  if (!rows.length) return res.redirect('/admin/pets');
  res.render('admin/edit-pet', { title: 'Edit Pet', pet: rows[0] });
});

router.post('/pets/edit/:id', async (req, res) => {
  await db.query('UPDATE pets SET pet_name=?, pet_type=?, breed=?, age=?, gender=?, description=?, vaccinated=?, status=? WHERE id=?',
    [...petFields(req.body), req.params.id]);
  req.session.flash = { type: 'success', msg: 'Pet updated successfully.' };
  res.redirect('/admin/pets');
});

router.post('/pets/delete/:id', async (req, res) => {
  await db.query('DELETE FROM pets WHERE id = ?', [req.params.id]);
  req.session.flash = { type: 'success', msg: 'Pet deleted.' };
  res.redirect('/admin/pets');
});

router.get('/requests', async (req, res) => {
  const pet = req.query.pet || '';
  let sql = `SELECT r.id, r.requested_at, r.status, u.name AS user_name, u.phone, p.id AS pet_id, p.pet_name
             FROM adoption_requests r JOIN users u ON u.id = r.user_id JOIN pets p ON p.id = r.pet_id`;
  const params = [];
  if (pet) { sql += ' WHERE p.id = ?'; params.push(pet); }
  sql += ' ORDER BY r.requested_at DESC';
  const [requests] = await db.query(sql, params);
  const [pets] = await db.query('SELECT id, pet_name FROM pets ORDER BY pet_name');
  res.render('admin/requests', { title: 'Adoption Requests', requests, pets, pet });
});

router.post('/requests/:id/approve', async (req, res) => {
  const [rows] = await db.query('SELECT * FROM adoption_requests WHERE id = ?', [req.params.id]);
  if (rows.length && rows[0].status === 'Pending') {
    await db.query("UPDATE adoption_requests SET status = 'Approved' WHERE id = ?", [req.params.id]);
    await db.query("UPDATE pets SET status = 'Adopted' WHERE id = ?", [rows[0].pet_id]);
    // Other pending requests for the same pet are rejected automatically
    await db.query("UPDATE adoption_requests SET status = 'Rejected' WHERE pet_id = ? AND id <> ? AND status = 'Pending'", [rows[0].pet_id, req.params.id]);
  }
  req.session.flash = { type: 'success', msg: 'Request approved. Pet marked as adopted.' };
  res.redirect('/admin/requests');
});

router.post('/requests/:id/reject', async (req, res) => {
  await db.query("UPDATE adoption_requests SET status = 'Rejected' WHERE id = ? AND status = 'Pending'", [req.params.id]);
  req.session.flash = { type: 'success', msg: 'Request rejected.' };
  res.redirect('/admin/requests');
});

module.exports = router;
