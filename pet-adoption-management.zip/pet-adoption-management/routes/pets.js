const express = require('express');
const db = require('../config/db');
const { requireLogin } = require('../middleware/auth');
const router = express.Router();

// List pets with optional filters
router.get('/pets', async (req, res) => {
  const { type = '', q = '' } = req.query;
  let sql = 'SELECT * FROM pets WHERE 1=1';
  const params = [];
  if (type) { sql += ' AND pet_type = ?'; params.push(type); }
  if (q) { sql += ' AND (pet_name LIKE ? OR breed LIKE ?)'; params.push(`%${q}%`, `%${q}%`); }
  sql += ' ORDER BY id';
  const [pets] = await db.query(sql, params);
  const [types] = await db.query('SELECT DISTINCT pet_type FROM pets ORDER BY pet_type');
  res.render('pets', { title: 'Pets', pets, types, type, q });
});

router.get('/pets/:id', async (req, res) => {
  const [rows] = await db.query('SELECT * FROM pets WHERE id = ?', [req.params.id]);
  if (!rows.length) return res.status(404).render('message', { title: 'Not Found', message: 'Pet not found.' });
  let existing = null;
  if (req.session.user) {
    const [r] = await db.query('SELECT * FROM adoption_requests WHERE user_id = ? AND pet_id = ?', [req.session.user.id, req.params.id]);
    existing = r[0] || null;
  }
  res.render('pet-details', { title: rows[0].pet_name, pet: rows[0], existing });
});

// Submit adoption request
router.post('/pets/:id/adopt', requireLogin, async (req, res) => {
  const petId = req.params.id;
  const userId = req.session.user.id;
  const back = `/pets/${petId}`;
  const [pets] = await db.query('SELECT * FROM pets WHERE id = ?', [petId]);
  if (!pets.length) return res.redirect('/pets');
  if (pets[0].status === 'Adopted') {
    req.session.flash = { type: 'error', msg: 'This pet has already been adopted.' };
    return res.redirect(back);
  }
  const [ex] = await db.query('SELECT * FROM adoption_requests WHERE user_id = ? AND pet_id = ?', [userId, petId]);
  if (ex.length) {
    if (ex[0].status === 'Cancelled') {
      await db.query("UPDATE adoption_requests SET status = 'Pending', requested_at = NOW() WHERE id = ?", [ex[0].id]);
      req.session.flash = { type: 'success', msg: 'Adoption request submitted again.' };
    } else {
      req.session.flash = { type: 'error', msg: 'You have already requested this pet.' };
    }
    return res.redirect(back);
  }
  await db.query("INSERT INTO adoption_requests (user_id, pet_id, status) VALUES (?, ?, 'Pending')", [userId, petId]);
  req.session.flash = { type: 'success', msg: 'Adoption request submitted successfully.' };
  res.redirect('/my-requests');
});

router.get('/my-requests', requireLogin, async (req, res) => {
  const [requests] = await db.query(
    `SELECT r.id, r.requested_at, r.status, p.pet_name, p.pet_type, p.breed
     FROM adoption_requests r JOIN pets p ON p.id = r.pet_id
     WHERE r.user_id = ? ORDER BY r.requested_at DESC`, [req.session.user.id]);
  res.render('my-requests', { title: 'My Requests', requests });
});

router.post('/my-requests/:id/cancel', requireLogin, async (req, res) => {
  await db.query("UPDATE adoption_requests SET status = 'Cancelled' WHERE id = ? AND user_id = ? AND status = 'Pending'",
    [req.params.id, req.session.user.id]);
  req.session.flash = { type: 'success', msg: 'Adoption request cancelled.' };
  res.redirect('/my-requests');
});

module.exports = router;
