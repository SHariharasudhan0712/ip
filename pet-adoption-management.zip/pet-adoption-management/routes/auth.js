const express = require('express');
const bcrypt = require('bcrypt');
const db = require('../config/db');
const router = express.Router();

// Home page
router.get('/', async (req, res) => {
  const [pets] = await db.query("SELECT * FROM pets WHERE status = 'Available' ORDER BY id LIMIT 6");
  res.render('index', { title: 'Home', pets });
});

router.get('/login', (req, res) => res.render('login', { title: 'Login' }));

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    req.session.flash = { type: 'error', msg: 'Email and password are required.' };
    return res.redirect('/login');
  }
  const [rows] = await db.query('SELECT * FROM users WHERE email = ?', [email.trim().toLowerCase()]);
  const ok = rows.length && await bcrypt.compare(password, rows[0].password);
  if (!ok) {
    req.session.flash = { type: 'error', msg: 'Invalid email or password.' };
    return res.redirect('/login');
  }
  const u = rows[0];
  req.session.user = { id: u.id, name: u.name, email: u.email, role: u.role };
  res.redirect(u.role === 'admin' ? '/admin/dashboard' : '/pets');
});

router.get('/register', (req, res) => res.render('register', { title: 'Register', form: {} }));

router.post('/register', async (req, res) => {
  const { name, email, phone, address, city, password, confirm_password } = req.body;
  const form = { name, email, phone, address, city };
  const fail = (msg) => res.render('register', { title: 'Register', form, error: msg });

  if (!name || !email || !phone || !address || !city || !password || !confirm_password) return fail('All fields are required.');
  if (!/^\S+@\S+\.\S+$/.test(email)) return fail('Enter a valid email address.');
  if (!/^[0-9]{10}$/.test(phone)) return fail('Phone number must be 10 digits.');
  if (password.length < 6) return fail('Password must be at least 6 characters.');
  if (password !== confirm_password) return fail('Passwords do not match.');

  const [dup] = await db.query('SELECT id FROM users WHERE email = ?', [email.trim().toLowerCase()]);
  if (dup.length) return fail('This email is already registered.');

  const hash = await bcrypt.hash(password, 10);
  await db.query(
    'INSERT INTO users (name, email, phone, address, city, password, role) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [name.trim(), email.trim().toLowerCase(), phone, address.trim(), city.trim(), hash, 'user']
  );
  req.session.flash = { type: 'success', msg: 'Registration successful. Please log in.' };
  res.redirect('/login');
});

router.get('/logout', (req, res) => req.session.destroy(() => res.redirect('/')));

module.exports = router;
