require('dotenv').config();
const express = require('express');
const session = require('express-session');
const path = require('path');

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: process.env.SESSION_SECRET || 'pet_secret',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 }
}));

// Make session user and flash messages available in every view
app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  res.locals.flash = req.session.flash || null;
  delete req.session.flash;
  next();
});

app.use('/', require('./routes/auth'));
app.use('/', require('./routes/pets'));
app.use('/admin', require('./routes/admin'));

app.use((req, res) => {
  res.status(404).render('message', { title: 'Not Found', message: 'The page you requested does not exist.' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Pet Adoption Management System running on http://localhost:${PORT}`));
