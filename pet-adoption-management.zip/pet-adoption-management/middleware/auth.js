function requireLogin(req, res, next) {
  if (!req.session.user) {
    req.session.flash = { type: 'error', msg: 'Please log in to continue.' };
    return res.redirect('/login');
  }
  next();
}

function requireAdmin(req, res, next) {
  if (!req.session.user || req.session.user.role !== 'admin') {
    return res.status(403).render('message', { title: 'Access Denied', message: 'Only administrators can access this page.' });
  }
  next();
}

module.exports = { requireLogin, requireAdmin };
