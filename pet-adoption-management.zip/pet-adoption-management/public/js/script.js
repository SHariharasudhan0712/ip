// Client-side validation for the registration form
document.addEventListener('DOMContentLoaded', function () {
  var form = document.getElementById('registerForm');
  if (!form) return;
  form.addEventListener('submit', function (e) {
    var f = form.elements;
    var msg = '';
    if (!/^\S+@\S+\.\S+$/.test(f.email.value)) msg = 'Enter a valid email address.';
    else if (!/^[0-9]{10}$/.test(f.phone.value)) msg = 'Phone number must be 10 digits.';
    else if (f.password.value.length < 6) msg = 'Password must be at least 6 characters.';
    else if (f.password.value !== f.confirm_password.value) msg = 'Passwords do not match.';
    if (msg) { e.preventDefault(); alert(msg); }
  });
});
