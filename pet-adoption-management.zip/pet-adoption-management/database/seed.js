// Creates tables, sample pets and the default admin account.
// Usage: node database/seed.js
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');

(async () => {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    multipleStatements: true
  });
  const sql = fs.readFileSync(path.join(__dirname, 'pet_adoption_management.sql'), 'utf8');
  await conn.query(sql);
  const hash = await bcrypt.hash('admin123', 10);
  await conn.query(
    'INSERT INTO pet_adoption_management.users (name, email, phone, address, city, password, role) VALUES (?,?,?,?,?,?,?)',
    ['Administrator', 'admin@petshelter.com', '9876543210', 'Shelter Road', 'Madurai', hash, 'admin']
  );
  console.log('Database ready. Admin login: admin@petshelter.com / admin123');
  await conn.end();
})().catch(e => { console.error(e); process.exit(1); });
