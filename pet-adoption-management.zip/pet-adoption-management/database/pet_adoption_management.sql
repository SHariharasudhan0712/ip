CREATE DATABASE IF NOT EXISTS pet_adoption_management;
USE pet_adoption_management;

DROP TABLE IF EXISTS adoption_requests;
DROP TABLE IF EXISTS pets;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  phone VARCHAR(15) NOT NULL,
  address VARCHAR(255) NOT NULL,
  city VARCHAR(80) NOT NULL,
  password VARCHAR(255) NOT NULL,
  role ENUM('user','admin') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE pets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pet_name VARCHAR(80) NOT NULL,
  pet_type VARCHAR(40) NOT NULL,
  breed VARCHAR(80) NOT NULL,
  age VARCHAR(30) NOT NULL,
  gender ENUM('Male','Female') NOT NULL DEFAULT 'Male',
  description TEXT,
  vaccinated ENUM('Yes','No') NOT NULL DEFAULT 'Yes',
  status ENUM('Available','Pending','Adopted') NOT NULL DEFAULT 'Available',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE adoption_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  pet_id INT NOT NULL,
  requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  status ENUM('Pending','Approved','Rejected','Cancelled') NOT NULL DEFAULT 'Pending',
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (pet_id) REFERENCES pets(id) ON DELETE CASCADE,
  UNIQUE KEY unique_request (user_id, pet_id)
);

INSERT INTO pets (pet_name, pet_type, breed, age, gender, description, vaccinated, status) VALUES
('Bruno', 'Dog', 'Labrador Retriever', '2 years', 'Male', 'Friendly and energetic. Loves playing fetch and gets along well with children.', 'Yes', 'Available'),
('Misty', 'Cat', 'Persian', '1 year', 'Female', 'Calm and affectionate lap cat with a fluffy white coat.', 'Yes', 'Available'),
('Coco', 'Rabbit', 'Holland Lop', '8 months', 'Female', 'Gentle and curious rabbit. Enjoys fresh carrots and hay.', 'Yes', 'Available'),
('Rocky', 'Dog', 'German Shepherd', '3 years', 'Male', 'Loyal and well trained. Best suited for a home with a garden.', 'Yes', 'Available'),
('Luna', 'Cat', 'Siamese', '2 years', 'Female', 'Playful and talkative. Very attached to her family.', 'Yes', 'Available'),
('Kiwi', 'Bird', 'Budgerigar', '1 year', 'Male', 'Colourful and cheerful bird that can mimic a few words.', 'No', 'Available'),
('Daisy', 'Dog', 'Indian Pariah', '1 year', 'Female', 'Healthy, alert and easy to train. Rescued from the street as a puppy.', 'Yes', 'Available'),
('Oreo', 'Cat', 'Domestic Shorthair', '4 months', 'Male', 'Black and white kitten full of energy.', 'Yes', 'Adopted');
