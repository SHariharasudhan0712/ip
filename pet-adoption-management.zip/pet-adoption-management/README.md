# Pet Adoption Management System
CS2307 – Internet Programming Lab Mini Project (Kamaraj College of Engineering and Technology)

**Stack:** HTML, CSS, JavaScript, EJS, Node.js, Express.js, MySQL, bcrypt, express-session

## Setup
1. Install Node.js and MySQL.
2. Copy `.env.example` to `.env` and set your MySQL user/password.
3. `npm install`
4. `node database/seed.js`   (creates the database, tables, sample pets and the admin account)
5. `npm start`  and open http://localhost:3000

Admin login: `admin@petshelter.com` / `admin123` (change after first login in a real deployment)
